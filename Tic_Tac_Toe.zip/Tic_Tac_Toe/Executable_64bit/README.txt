Created by Somil Govani

Open tictacmenu.exe to play.
Do not rename any files.
Make sure to keep them all in one folder.