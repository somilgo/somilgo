Tic Tac Toe
By Somil Govani
-----------------------

Run tictacmenu.py to play.

This tic tac toe game is written in Python and it uses the Tkinter module in order to implement the GUI. Originally, I used a conditional AI, but I updated this with a much more clever minimax AI. 

Thanks for playing!