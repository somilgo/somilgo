Algorithmic Composition with Pure Data
Somil Govani

This is a program I developed for the science fair that generates music spontaneously. (See abstract for full description).

To view patches, download PureData from http://puredata.info/ and configure MIDI settings. (The version marked *loadbang* is the official version that I presented).

Open it and click the bang (circle shaped button) to start music. 

View .pdf 'Presentation of Concepts' for full description.
