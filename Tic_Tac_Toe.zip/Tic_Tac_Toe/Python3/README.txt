Created by Somil Govani

Run tictacmenu.py to play.