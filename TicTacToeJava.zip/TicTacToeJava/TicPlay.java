import javax.swing.*;

//Brady Boylan and Somil Govani
//Tuesday June 2nd, 2015
//Block 1
//Driver class for TicTacToe class

public class TicPlay
{
	public static void main (String[] args)
	{
		new TicTacToe ();//Call TicTacToe Constructor
	}
}