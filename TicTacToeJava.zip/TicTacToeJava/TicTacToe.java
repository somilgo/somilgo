import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import javax.swing.*;

//Brady Boylan and Somil Govani
//Tuesday June 2nd, 2015
//Block 1
//TicTacToe class with GUI and pertinent methods

public class TicTacToe
{
	private JFrame board;
	private JButton[] buttons;
	private boolean turnX;
	private static final int boardLength = 3;
	private JRadioButtonMenuItem playerChoiceX;
	private JRadioButtonMenuItem playerChoiceO;
	private JLabel XScore;
	private JLabel OScore;
	private int XWins;
	private int OWins;
	
	/**
		Constructs TicTacToe board GUI and generates buttons and menus with buttons
	*/
	public TicTacToe ()
	{
		//Creates Frame and sets grid layout
		board = new JFrame();
		turnX = true;
		GridLayout layout = new GridLayout (boardLength, boardLength);
    	board.setLayout(layout);
    	buttons = new JButton[boardLength * boardLength];//Board is a perfect square
    	Font big = new Font("Arial", Font.PLAIN, 50); 
    	XWins = 0;
    	OWins = 0;
    	
    	//Creates menuBar
    	JMenuBar menuBar = new JMenuBar();
		JMenu menu = new JMenu("File");
		JMenuItem newGame = new JMenuItem("New Game");
		JMenuItem exit = new JMenuItem("Exit");
		//File>Exit method
		exit.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent event) {
	            System.exit(0);
	        }
		});
		//File>New Game method
		newGame.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed (ActionEvent e)
			{
				for (JButton b : buttons)
				{
					b.setEnabled(true);
					b.setText("");
				}
				if (playerChoiceX.isSelected())
				{
					turnX = true;
				}
				else
				{
					turnX = false;
				}
			}
		});
    	menu.add(newGame);
    	menu.add(exit);
		JMenu playerMenu = new JMenu ("Who Goes First?");
		menuBar.add(menu);
		
		//Makes menu to choose which player goes first in next game
		menuBar.add(playerMenu);
		board.setJMenuBar(menuBar);
		ButtonGroup group = new ButtonGroup();
		playerChoiceX = new JRadioButtonMenuItem ("Player X First");
		playerChoiceX.setSelected(true);
		group.add(playerChoiceX);
		playerMenu.add(playerChoiceX);
		playerChoiceO = new JRadioButtonMenuItem ("Player O First");
		group.add(playerChoiceO);
		playerMenu.add(playerChoiceO);
    	
    	//Scoreboard
		XScore = new JLabel("Player X: " + XWins + "  ");
		OScore = new JLabel("Player O: " + OWins + "   ");
		
		menuBar.add(Box.createHorizontalGlue());
		menuBar.add(XScore);
		menuBar.add(OScore);
		
		//Generates all buttons with button actionListeners in grid
    	for (int i = 0; i < (boardLength * boardLength); i++)
    	{
    		buttons[i] = new JButton ("");
    		board.add(buttons[i]);
    		//
    		buttons[i].addActionListener(new ActionListener(){
    			@Override
    			public void actionPerformed(ActionEvent e) 
				{
					String turn = "X";
					if (turnX)
					{
						turn = "X";
						turnX = false;
					}
					else
					{
						turn = "O";
						turnX = true;
					}
					if (((JButton)(e.getSource())).getText().equals(""))
					{
						((JButton)(e.getSource())).setText(turn);
						((JButton)(e.getSource())).setEnabled(false);
					}
					
					ArrayList<JButton> winList = checkWin(java.util.Arrays.asList(buttons).indexOf(((JButton)(e.getSource()))));
					
					if (winList != null)
					{
						if (turn.equals("X"))
						{
							XWins++;
							XScore.setText("    Player X: " + XWins + "  ");
						}
						else
						{
							OWins++;
							OScore.setText("Player O: " + OWins + "   ");
						}
						for (JButton j : winList)
						{
							j.setText("<html><font color = \"red\">" + turn + "</font></html>");
						}
						for (JButton b : buttons)
						{
							b.setEnabled(false);
						}
					}
				}	
			});
    		buttons[i].setFont(big);
    	}
    	
    	//Board settings
		board.setSize(500, 500);
		board.setResizable(true);
		board.setLocationRelativeTo(null);
		board.setTitle("Somil and Brady's Tic Tac Toe Game");
		board.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		board.setVisible(true);
	}
	
	/**
	 ArrayList to determines who wins the game
	 @param butInd index of last clicked button
	 */
	public ArrayList<JButton> checkWin (int butInd)
	{
		int index = turn;
		ArrayList<JButton> winRow1 = new ArrayList<JButton>();
		while (index >= boardLength)
		{
			index -= boardLength;
		}
		
		String winner = buttons[index].getText();
		winRow1.add(buttons[index]);
		
		//Check for vertical win
		for (int i = index; i < buttons.length; i+=boardLength)
		{
			if(buttons[i].getText() != "" && buttons[i].getText().equals(winner))
			{
				winRow1.add(buttons[i]);
				if ((i+boardLength) >= buttons.length)
				{
					return winRow1;
				}
			}
			else
			{
				break;
			}
		}
		winRow1.clear();
		index = turn;
		while((index % boardLength) != (boardLength - 1))
		{
			index++;
		}
		winner = buttons[index].getText();
		winRow1.add(buttons[index]);
		
		//Check for horizonal win
		for (int j = 1; j < boardLength; j++)
		{
			if(buttons[index - j].getText() != "" && buttons[index - j].getText().equals(winner))
			{
				winRow1.add(buttons[index - j]);
				if (j == boardLength - 1)
				{
					return winRow1;
				}
			}
			else
			{
				break;
			}
		}
		winRow1.clear();
		winner = buttons[0].getText();
		winRow1.add(buttons[0]);
		
		//Check for negative slope diagonal win
		for (int p = boardLength + 1; p < buttons.length; p+= (boardLength + 1))
		{
			if(buttons[p].getText() != "" && buttons[p].getText().equals(winner))
			{
				winRow1.add(buttons[p]);
				if (p+1 == buttons.length)
				{
					return winRow1;
				}
			}
			else
			{
				break;
			}
		}
		winRow1.clear();
		index = boardLength * (boardLength - 1);
		winner = buttons[index].getText();
		winRow1.add(buttons[index]);
		
		//Check for positive slope diagonal win
		for (int f = index - (boardLength - 1); f > 0; f-=(boardLength-1))
		{
			if(buttons[f].getText() != "" && buttons[f].getText().equals(winner))
			{
				winRow1.add(buttons[f]);
				if (f - boardLength < 0)
				{
					return winRow1;
				}
			}
			else
			{
				break;
			}
		}
		
		return null;
		
	}

}