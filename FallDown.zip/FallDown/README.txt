FallDown

By Somil Govani


Use the arrow keys to move the ball towards the bottom of the screen in order to avoid getting crushed by moving platforms. 

Controls
---------

Right and left arrow keys to move

"M" toggles music
"S" toggles sound fx


